'''

TLDector for detecting traffic light by image

'''


from tl_helper import TLHelper


class TLDetector(object):
    def __init__(self, *args, **kwargs):
        pass

